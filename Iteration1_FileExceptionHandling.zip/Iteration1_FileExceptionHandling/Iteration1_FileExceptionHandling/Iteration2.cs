﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Iteration1_FileExceptionHandling
{
    public class Employee()
    {
        public string name;
        public string gender;
        public string manager;
        public string team;
        public string role;
        public string joining;
    }

    public static bool SearchByName(string name)
    {
        if (name == null) { }
    }

    public class Iteration2
    {




    }
}
